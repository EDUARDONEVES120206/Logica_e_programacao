<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicial</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <center>
        <form action="index.php" method="POST">
            <input type="text" name="valor_1" placeholder="Primeiro Numero">
            <br><br>
            <input type="text" name="valor_2" placeholder="Segundo Numero">
            <br><br><br><br>
            <select name="oper">
                <option value="soma" name="soma">Soma</option>
                <option value="sub" name="sub">Subtração</option>
                <option value="mul" name="mul">multiplicação</option>
                <option value="div" name="div">Divisão</option>
            </select>
            <br><br>
            <button>enviar</button>
        </form>
    </center>
    <?php
    echo "<center> ";
    $n1 = $_POST['valor_1'];
    $n2 = $_POST['valor_2'];
    $oper = $_POST['oper'];
    if ($oper == "soma") {
        $resul_soma = $n1 + $n2;
        echo "<h4> a soma entre os dois numeros e: </h4> $resul_soma";
    } elseif ($oper == "sub") {
        $resul_sub = $n1 - $n2;
        echo "<h4> a subtracao entre os dois numeros e: </h4> $resul_sub";
    } elseif ($oper == "mul") {
        $resul_mul = $n1 * $n2;
        echo "<h4> a multiplicacao entre os dois numeros e: </h4> $resul_mul";
    } elseif ($oper == "div") {
        $resul_div = $n1 / $n2;
        echo "<h4> a divisao entre os dois numeros e: </h4> <h2>$resul_div</h2>";
    } else {
        echo "opcção Invalido";
    }
    echo "</center>";
    ?>
</body>

</html>